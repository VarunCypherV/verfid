package com.example.VerifID;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VerifIdApplication {

	public static void main(String[] args) {
		SpringApplication.run(VerifIdApplication.class, args);
	}

}
