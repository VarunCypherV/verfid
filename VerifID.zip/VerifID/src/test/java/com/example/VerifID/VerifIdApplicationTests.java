package com.example.VerifID;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VerifIdApplicationTests {

	@Test
	void contextLoads() {
	}

}
